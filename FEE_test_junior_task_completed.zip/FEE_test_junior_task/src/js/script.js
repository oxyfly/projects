// 'use strict';

import jQuery from 'jquery';
import 'popper.js';
import 'bootstrap';
import '../scss/style.scss';

// nav mobile
(function ($) {
  $(function () {

    $('.nav-mobile-wrapper ul li a:not(:only-child)').click(function (e) {
      $(this).siblings('.nav-dropdown').toggle();
      // Close one dropdown when selecting another
      $('.nav-dropdown').not($(this).siblings()).hide();
      e.stopPropagation();
    });

    $('html').click(function () {
      $('.nav-dropdown').hide();
    });

    $('#nav-toggle').click(function () {
      $('.nav-mobile-wrapper ul').slideToggle();
    });

    $('#nav-toggle').on('click', function () {
      this.classList.toggle('active');
    });
  });
})(jQuery);